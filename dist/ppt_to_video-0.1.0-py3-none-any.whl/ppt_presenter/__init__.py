"""
PowerPoint Presentation to Video Package

This package provides functionalities to:
1. Extract content from PowerPoint slides.
2. Convert text to audio files.
3. Convert PowerPoint slides to images.
4. Combine images and audio to create a video presentation.
"""

from .content_extractor import extract_ppt_content
from .text_to_audio import get_audio
from .ppt_to_images import convert_ppt_to_images
from .video_creator import create_video_from_images_and_audio

__all__ = [
    "extract_ppt_content",
    "get_audio",
    "convert_ppt_to_images",
    "create_video_from_images_and_audio",
]
