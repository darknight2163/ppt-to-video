from pptx import Presentation
from tqdm import tqdm  # Import tqdm for progress bar

def extract_ppt_content(ppt_path):
    """
    Extracts content from each slide of a PowerPoint presentation.

    Args:
        ppt_path (str): Path to the PowerPoint file.

    Returns:
        list: A list where each index contains the content of a slide.
    """
    # Load the presentation
    presentation = Presentation(ppt_path)
    slide_contents = []

    # Total number of slides
    total_slides = len(presentation.slides)

    # Loop through each slide with progress bar
    for slide in tqdm(presentation.slides, desc="Extracting Slides content", total=total_slides, unit="slide"):
        slide_text = []
        # Extract text from all shapes in the slide
        for shape in slide.shapes:
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    slide_text.append(paragraph.text)
        slide_contents.append(" ".join(slide_text))

    return slide_contents