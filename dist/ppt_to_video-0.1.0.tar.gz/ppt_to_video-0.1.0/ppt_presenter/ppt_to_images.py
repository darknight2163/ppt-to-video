import os
import subprocess
from pdf2image import convert_from_bytes

def convert_ppt_to_images(pptfile_path):
    img_format = "jpg"
    out_dir = "./slide_images"  # Output directory in Colab
    filename_base = os.path.basename(pptfile_path)
    filename_bare = os.path.splitext(filename_base)[0]

    # Convert PPTX to PDF using LibreOffice (soffice)
    command_list = ["soffice", "--headless", "--convert-to", "pdf", pptfile_path]
    subprocess.run(command_list)

    pdffile_name = filename_bare + ".pdf"
    with open(pdffile_name, "rb") as f:
        pdf_bytes = f.read()

    images = convert_from_bytes(pdf_bytes, dpi=96)

    if not os.path.exists(out_dir):
        os.mkdir(out_dir)

    for i, img in enumerate(images):
        img_name = os.path.join(out_dir, f"slide_{i+1}.{img_format}")
        img.save(img_name)

    if os.path.exists(pdffile_name):
      os.remove(pdffile_name)
      print(f"Removed created PDF file: {pdffile_name}")

    print(f"Conversion done, images saved in dir {out_dir}")

