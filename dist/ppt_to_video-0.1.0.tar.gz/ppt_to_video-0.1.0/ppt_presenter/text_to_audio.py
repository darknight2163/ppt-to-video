from gtts import gTTS
from tqdm import tqdm
import os

def get_audio(slide_contents, output_folder="slide_audios"):
    """
    Converts a list of slide contents into audio files with a progress bar.

    Args:
        slide_contents (list): List where each index contains the content of a slide.
        output_folder (str): Folder to save the audio files.
    """
    # Ensure the output folder exists
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    print("Generating audio files for slides...")

    # Iterate through the slides with a progress bar
    for i, content in enumerate(tqdm(slide_contents, desc="Processing Slides", unit="slide"), start=1):
        if content.strip():  # Only process non-empty content
            audio_file = os.path.join(output_folder, f"slide_{i}.mp3")
            tts = gTTS(text=content, lang='en')
            tts.save(audio_file)
        else:
            print(f"Slide {i} has no content. Skipping...")

    print(f"\nAudio files saved in the folder: {output_folder}")
