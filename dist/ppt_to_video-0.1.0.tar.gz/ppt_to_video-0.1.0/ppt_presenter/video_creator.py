import os
import cv2
from pydub import AudioSegment
import subprocess
from tqdm import tqdm

def create_video_from_images_and_audio(image_folder, audio_folder, output_video_file):
    image_files = sorted([f for f in os.listdir(image_folder) if f.endswith('.jpg')])
    audio_files = sorted([f for f in os.listdir(audio_folder) if f.endswith('.mp3')])

    if len(image_files) != len(audio_files):
        print("Error: The number of images and audio files must be the same!")
        return

    # Create a temporary list to store the individual video parts
    video_parts = []

    # Create video parts for each image/audio pair with progress bar
    for i, image_file in enumerate(tqdm(image_files, desc="Processing images and audio")):
        # Read the image
        img_path = os.path.join(image_folder, image_file)
        img = cv2.imread(img_path)
        height, width, layers = img.shape

        # Create a temporary video file for this image
        temp_video_path = f"temp_video_part_{i}.mp4"
        video_writer = cv2.VideoWriter(temp_video_path, cv2.VideoWriter_fourcc(*'mp4v'), 8, (width, height))  # 8 fps
        video_writer.write(img)  # Write the single image as a video frame
        video_writer.release()

        # Process the corresponding audio
        audio_path = os.path.join(audio_folder, audio_files[i])
        audio_clip = AudioSegment.from_mp3(audio_path)

        # Save the audio as a temporary file
        temp_audio_path = f"temp_audio_part_{i}.mp3"
        audio_clip.export(temp_audio_path, format="mp3")

        # Combine the video part and the audio using FFmpeg
        output_video_with_audio = f"temp_video_part_{i}_with_audio.mp4"
        ffmpeg_command = [
            "ffmpeg", "-y", "-i", temp_video_path, "-i", temp_audio_path, "-c:v", "libx264", "-c:a", "aac", "-strict", "experimental", output_video_with_audio
        ]
        subprocess.run(ffmpeg_command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Add the video part with audio to the list
        video_parts.append(output_video_with_audio)

        # Clean up temporary files
        os.remove(temp_video_path)
        os.remove(temp_audio_path)

    # Now, concatenate all the video parts using FFmpeg
    concat_file = "concat_list.txt"
    with open(concat_file, "w") as f:
        for video_part in video_parts:
            f.write(f"file '{video_part}'\n")

    # Final output video after merging all parts
    final_output = output_video_file.replace(".mp4", "_result.mp4")
    ffmpeg_concat_command = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_file, "-c", "copy", final_output
    ]
    subprocess.run(ffmpeg_concat_command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # Clean up temporary files and the concat list
    for video_part in video_parts:
        os.remove(video_part)
    os.remove(concat_file)

    print(f"Video created successfully: {final_output}")
