from setuptools import setup, find_packages

# Read the README file for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ppt-to-video",  # Replace with your package name
    version="0.1.0",
    author="Shivam Kumar",
    author_email="shivamkr2163@gmail.com",
    description="Convert PowerPoint presentations into videos with audio narration.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/darknight2163/ppt-to-video",  # Replace with your GitHub repo link
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "python-pptx==1.0.2",
        "gtts==2.5.4",
        "tqdm==4.67.1",
        "pdf2image==1.17.0",
        "moviepy==1.0.3",
        "pydub==0.25.1",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=23.0",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "ppt-to-video=ppt_to_video.cli:main",  # Optional: add a CLI if needed
        ],
    },
)
